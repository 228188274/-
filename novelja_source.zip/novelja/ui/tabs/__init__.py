"""
UI tabs.
"""

