"""
Qt UI layer.
"""

