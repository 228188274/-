"""
Dialogs used by tabs.
"""

