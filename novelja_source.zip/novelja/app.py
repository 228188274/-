from __future__ import annotations

import sys

from PySide6.QtWidgets import QApplication

from novelja.ui.main_window import MainWindow
from novelja.ui.app_state import get_app_state
from novelja.ui.theme import apply_theme
from novelja.core.security import load_ui_theme


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("小说佳")
    app.setOrganizationName("novelja")
    # Initialize global app state (cross-tab project sharing)
    get_app_state()
    apply_theme(app, load_ui_theme())

    window = MainWindow()
    window.show()
    return app.exec()

